<footer id="footer">
<div id="social-container">
<ul>
<li>
<a href="#"><i class="fab fa-facebook-square"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-instagram"></i></a>
</li>

<li>
<a href="#"><i class="fab fa-youtube"></i></a>
</li>
</ul>
</div>
<div id="footer-links-container">
<ul>
<li><a href="#">Adicionar filme</a></li>
<li><a href="#">Adicionar crítica</a></li>
<li><a href="#">Entrar / Registrar</a></li>
</ul>
</div>
<p>&copy; 2025 Cleysson Antunes Oliveira</p>
</footer>
</body>
</html>